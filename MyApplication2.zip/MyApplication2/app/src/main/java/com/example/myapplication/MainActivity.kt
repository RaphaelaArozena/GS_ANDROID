import android.os.Bundle
import android.text.TextUtils
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.Praia
import com.example.myapplication.R
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var praiaAdapter: PraiaAdapter
    private val praias = mutableListOf<Praia>()

    // Declaração das variáveis de instância
    private lateinit var etNomePraia: EditText
    private lateinit var etCidade: EditText
    private lateinit var etEstado: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicialização das variáveis de instância
        etNomePraia = findViewById(R.id.etNomePraia)
        etCidade = findViewById(R.id.etCidade)
        etEstado = findViewById(R.id.etEstado)

        praiaAdapter = PraiaAdapter(praias, this::onExcluirClicked)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = praiaAdapter

        btnIncluir.setOnClickListener {
            val nome = etNomePraia.text.toString()
            val cidade = etCidade.text.toString()
            val estado = etEstado.text.toString()

            if (validarCampos(nome, cidade, estado)) {
                val praia = Praia(nome, cidade, estado)
                praias.add(praia)
                praiaAdapter.notifyDataSetChanged()
                limparCampos()
            }
        }
    }

    private fun validarCampos(nome: String, cidade: String, estado: String): Boolean {
        if (TextUtils.isEmpty(nome) || TextUtils.isEmpty(cidade) || TextUtils.isEmpty(estado)) {
            Toast.makeText(this, "Todos os campos devem ser preenchidos", Toast.LENGTH_SHORT).show()
            return false
        }
        if (nome.length < 3 || cidade.length < 3 || estado.length < 2) {
            Toast.makeText(this, "Campos não atendem aos requisitos mínimos", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun limparCampos() {
        etNomePraia.text.clear()
        etCidade.text.clear()
        etEstado.text.clear()
    }

    private fun onExcluirClicked(praia: Praia) {
        praias.remove(praia)
        praiaAdapter.notifyDataSetChanged()
    }
}
