package com.example.myapplication

data class Praia(
    val nome: String,
    val cidade: String,
    val estado: String
)
