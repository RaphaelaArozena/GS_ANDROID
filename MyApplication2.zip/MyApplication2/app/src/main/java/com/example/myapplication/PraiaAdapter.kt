import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.Praia
import com.example.myapplication.R

class PraiaAdapter(
    private val praias: List<Praia>,
    private val onExcluirClicked: (Praia) -> Unit
) : RecyclerView.Adapter<PraiaAdapter.PraiaViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PraiaViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_praia, parent, false)
        return PraiaViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: PraiaViewHolder, position: Int) {
        val praia = praias[position]
        holder.bind(praia)
    }

    override fun getItemCount(): Int = praias.size

    inner class PraiaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvPraiaInfo: TextView = itemView.findViewById(R.id.tvNomePraia)
        private val btnExcluir: Button = itemView.findViewById(R.id.btnExcluir)

        fun bind(praia: Praia) {
            tvPraiaInfo.text = "${praia.nome}, ${praia.cidade}, ${praia.estado}"
            btnExcluir.setOnClickListener { onExcluirClicked(praia) }
        }
    }
}
